import { ScanFace } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useRef, useEffect } from 'react';

// ====== 模拟的后端 API 接口层 ======
// 未来这里将替换为真实的 WebSocket (ws.onmessage) 或 API 轮询逻辑
function useFaceScanningAPI(isRecording: boolean) {
  const [instruction, setInstruction] = useState('请看向前方');

  useEffect(() => {
    if (!isRecording) {
      setInstruction('请看向前方');
      return;
    }

    // 这里是模拟后端下发实时指令的过程
    // 实际开发时，这里将替换为:
    // const ws = new WebSocket('wss://api.yourbackend.com/enroll');
    // ws.onmessage = (event) => { 
    //    const data = JSON.parse(event.data);
    //    if (data.type === 'ACTION_REQUIRED') setInstruction(data.text);
    // }
    const steps = [
      { text: '请看向前方', time: 0 },
      { text: '请向左转头', time: 2500 },
      { text: '请向右转头', time: 5000 },
      { text: '请向下转头', time: 7500 },
      { text: '请向上转头', time: 10000 },
    ];

    const timers = steps.map(step => 
      setTimeout(() => setInstruction(step.text), step.time)
    );

    return () => {
      timers.forEach(clearTimeout);
      // if (ws) ws.close();
    };
  }, [isRecording]);

  return instruction;
}

export function ActionArea({ onSuccess }: { onSuccess?: () => void }) {
  const [status, setStatus] = useState<'idle' | 'recording' | 'success' | 'failure'>('idle');
  
  // 通过自定义 Hook 接入“后端”指令数据流
  const instruction = useFaceScanningAPI(status === 'recording');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (status === 'recording') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [status]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (status === 'success') {
      // 识别成功动画展示1.5秒后自动跳转
      timer = setTimeout(() => {
        setStatus('idle');
        if (onSuccess) onSuccess();
      }, 1500);
    } else if (status === 'failure') {
      // 识别失败动画展示1.5秒后回到初始状态
      timer = setTimeout(() => {
        setStatus('idle');
      }, 1500);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [status, onSuccess]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  return (
    <div className="relative z-50 flex flex-1 flex-col items-center justify-center gap-28">
      <AnimatePresence mode="wait">
        {status === 'idle' && (
          <motion.div
            key="icon"
            initial={{ scale: 0.9, opacity: 0, filter: 'blur(10px)', rotateY: 0 }}
            animate={{ scale: 1, opacity: 1, filter: 'blur(0px)', rotateY: 0 }}
            exit={{ scale: 0.8, opacity: 0, rotateY: 90, filter: 'blur(10px)' }}
            transition={{ type: "spring", stiffness: 150, damping: 20 }}
            className="relative flex h-40 w-40 items-center justify-center"
          >
            {/* A subtle glowing presence behind the key visual element */}
            <div className="absolute inset-0 rounded-full bg-[#0066b8]/10 blur-2xl" />
            <ScanFace 
              className="relative z-10 h-28 w-28 text-[#0066b8] drop-shadow-md" 
              strokeWidth={1.5}
            />
          </motion.div>
        )}
        
        {status === 'recording' && (
          <motion.div
            key="camera"
            initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
            animate={{ scale: 1, opacity: 1, rotateY: 0 }}
            exit={{ scale: 0.8, opacity: 0, rotateY: 90 }}
            transition={{ type: "spring", stiffness: 150, damping: 20 }}
            className="flex flex-col items-center gap-8"
          >
            <div className="relative flex h-64 w-64 items-center justify-center rounded-full bg-slate-100 shadow-xl overflow-hidden p-1">
              {/* Spinning scanning ring */}
              <div 
                className="absolute inset-0 animate-spin"
                style={{
                  backgroundImage: 'conic-gradient(from 0deg, transparent 0 120deg, #007acc 180deg, transparent 180deg 300deg, #007acc 360deg)',
                  animationDuration: '4s',
                  animationTimingFunction: 'linear'
                }}
              />
              
              <div className="relative h-full w-full rounded-full overflow-hidden bg-black z-10">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="h-full w-full object-cover scale-x-[-1]" /* Mirror the video */
                />
                {/* Overlay scanning effect */}
                <motion.div 
                  animate={{ y: ["-10%", "150%"] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-transparent to-[#007acc]/30 border-b-2 border-[#007acc]/80"
                />
              </div>
            </div>

            <div className="h-8 flex items-center justify-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={instruction}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="text-lg font-bold text-slate-800 tracking-widest"
                >
                  {instruction}
                </motion.div>
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {status === 'success' && (
          <motion.div
            key="success"
            initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
            animate={{ scale: 1, opacity: 1, rotateY: 0 }}
            exit={{ scale: 0.8, opacity: 0, filter: 'blur(10px)' }}
            transition={{ type: "spring", stiffness: 150, damping: 20 }}
            className="relative flex h-40 w-40 items-center justify-center rounded-full bg-white shadow-xl border border-green-100"
          >
            <div className="absolute inset-0 rounded-full bg-green-500/10 blur-xl" />
            <svg className="relative z-10 w-20 h-20 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </motion.div>
        )}

        {status === 'failure' && (
          <motion.div
            key="failure"
            initial={{ scale: 0.8, opacity: 0, rotateY: -90 }}
            animate={{ scale: 1, opacity: 1, rotateY: 0 }}
            exit={{ scale: 0.8, opacity: 0, filter: 'blur(10px)' }}
            transition={{ type: "spring", stiffness: 150, damping: 20 }}
            className="relative flex h-40 w-40 items-center justify-center rounded-full bg-white shadow-xl border border-red-100"
          >
            <div className="absolute inset-0 rounded-full bg-red-500/10 blur-xl" />
            <svg className="relative z-10 w-20 h-20 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="popLayout">
        {status === 'idle' && (
          <motion.button
            key="start-btn"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setStatus('recording')}
            className="rounded-full bg-[#0066b8] px-32 py-3 text-base font-bold tracking-wider text-white shadow-lg shadow-[#0066b8]/20 transition-all hover:bg-[#005a9e] focus:outline-none active:bg-[#004c87]"
          >
            开始录入
          </motion.button>
        )}
        
        {status === 'recording' && (
          <motion.div
            key="cancel-group"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex flex-col items-center gap-4"
          >
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setStatus('idle')}
              className="rounded-full bg-slate-200 px-32 py-3 text-base font-bold tracking-wider text-slate-700 shadow-md transition-all hover:bg-slate-300 focus:outline-none active:bg-slate-400"
            >
              取消录入
            </motion.button>
            <div className="flex gap-4 opacity-30 hover:opacity-100 transition-opacity">
              <button 
                onClick={() => setStatus('success')}
                className="text-xs text-slate-400 hover:text-green-600 transition-colors px-2 py-1"
              >
                [模拟成功]
              </button>
              <button 
                onClick={() => setStatus('failure')}
                className="text-xs text-slate-400 hover:text-red-600 transition-colors px-2 py-1"
              >
                [模拟失败]
              </button>
            </div>
          </motion.div>
        )}

        {status === 'success' && (
          <motion.div
            key="success-text"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="px-32 py-3 text-base font-bold tracking-wider text-green-600"
          >
            录入成功
          </motion.div>
        )}

        {status === 'failure' && (
          <motion.div
            key="failure-text"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="px-32 py-3 text-base font-bold tracking-wider text-red-600"
          >
            录入失败
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
